import java.util.Scanner;

public class nama {
	void identitas(String nama) {
	System.out.println("Masukkan nama anda "+nama);
	}
}